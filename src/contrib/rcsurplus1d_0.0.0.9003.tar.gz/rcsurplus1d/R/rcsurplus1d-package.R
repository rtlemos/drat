#' rcsurplus: title
#'
#' Description
#'
#' @docType package
#' @name rcsurplus1d
NULL
#> NULL
