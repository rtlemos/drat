# rcsurplus
R package to fit surplus production models (fisheries).
Reference: Rankin and Lemos, 2015. An alternative surplus production model. Ecological Modeling 313:106-126.
To run models, you must have OpenBUGS installed on your machine.
