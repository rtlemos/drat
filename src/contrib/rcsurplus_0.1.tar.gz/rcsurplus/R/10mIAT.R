.IAT <- setRefClass(
    Class = '.IAT'
)