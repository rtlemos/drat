rcsurplus_gui <- function(){
  shiny::runApp( system.file('rcsurplus_shiny', package='rcsurplus'), launch.browser=TRUE )
}