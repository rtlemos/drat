###########################################################
# RTL about:
# Folder created with
# > devtools::use_testthat()
# Run with
# > devtools::test()
# In folder tests/testthat, files are prefixed with "test-"
###########################################################
library(testthat)
library(rcrandom)

test_check("rcrandom")
